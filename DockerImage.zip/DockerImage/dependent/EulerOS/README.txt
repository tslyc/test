说明：
EulerOS下有两个目录【comm】和【special】，comm目录下的文件会直接覆盖拷贝到原始目录，special会根据指导模板进行构建