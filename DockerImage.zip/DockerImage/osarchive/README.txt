说明：
目前基础镜像的OS仅支持三种Linux操作类型【CentOS, EulerOS和Ubuntu】,这三种系统目前主力支持EulerOS
OS归档分为当前使用版本（见【active】目录）和历史版本（见【retired】）目录，当前使用版本各服务仅保留
一个，历史版本则保留最近使用的三个，更早的版本则不再保留