package main

import (
	"flag"
	"fmt"
	"jsonparse/operation"
	"os"
)

var srcPath = flag.String("s", "", "传入配置文件路径")

func main() {
	flag.Parse()
	if srcPath == nil {
		fmt.Println("[main] call GetConfig Path failed")
		os.Exit(1)
	}
	data, err := operation.GetConfigFromPath(*srcPath)
	if err != nil || data == "" {
		fmt.Println("[main] call GetConfigFromPath() failed[",err,"]")
		os.Exit(2)
	}
	support :=operation.Support{}
	if err := support.Unmarshal([]byte(data)); err != nil {
		fmt.Println("[main] call Unmarshal() failed[",err,"]")
		os.Exit(3)
	}
	if err := support.Cook(); err != nil {
		fmt.Println("[main] call Cook() failed[",err,"]")
		os.Exit(4)
	}
	/*sup:= operation.Support{
		RootDirList: []string{"sbin","bin","etc","home","lib","lib64","opt","usr","var"},
		Group:[]operation.OperateGroup{
			{
				RootName: "bin",
				List: []operation.OperateUnit {
					{

					},
					{

					},
				},
			},
			{
				RootName: "lib64",
				List: []operation.OperateUnit {
					{
						LinkInfo: &operation.LinkInfo {

						},
					},
					{

					},
				},
			},
		},
	}
	dat, err := json.Marshal(sup)
	if err != nil {
		fmt.Println(err)
		return
	}
	fmt.Println(string(dat))*/
}
