package operation

const (
	DefaultMaxFilePath = 1024
	DefaultFileMaxSize = 5 * 1024 * 1024 // 最大5M

	SrcPathMaxSize = 512
	DstPathMaxSize = 512
)

// 定义文件类型
type FileType string

// 文件类型常量
const (
	ExecFile       FileType = "exec"          // 可执行二进制文件
	BinaryFile     FileType = "bin"        // 普通二进制文件
	DynamicLibrary FileType = "dynamic_lib"
	StaticLibrary  FileType = "static_lib"
	TextFile       FileType = "text"
	MediaFile      FileType = "media"
	SoftLinkFile   FileType = "soft_link"
)

// 定义支持的文件类型
var fileSupport = map[FileType]bool{
	ExecFile:       true,
	BinaryFile:     true,
	DynamicLibrary: true,
	StaticLibrary:  true,
	TextFile:       true,
	SoftLinkFile:   true,
}

type RootName string

// 文件类型常量
const (
	RootBin   RootName = "bin"
	RootDev   RootName = "dev"
	RootEtc   RootName = "etc"
	RootHome  RootName = "home"
	RootInit  RootName = "init"
	RootLib   RootName = "lib"
	RootLib64 RootName = "lib64"
	RootMedia RootName = "media"
	RootMnt   RootName = "mnt"
	RootOpt   RootName = "opt"
	RootProc  RootName = "proc"
	RootRoot  RootName = "root"
	RootRun   RootName = "run"
	RootSBin  RootName = "sbin"
	RootSrv   RootName = "srv"
	RootSys   RootName = "sys"
	RootTmp   RootName = "tmp"
	RootUsr   RootName = "usr"
	RootVar   RootName = "var"
)

// 定义支持的基本路径类型
var rootSupport = map[RootName]bool{
	RootBin:   true,
	RootDev:   true,
	RootEtc:   true,
	RootHome:  true,
	RootInit:  true,
	RootLib:   true,
	RootLib64: true,
	RootMedia: true,
	RootMnt:   true,
	RootOpt:   true,
	RootProc:  true,
	RootRoot:  true,
	RootRun:   true,
	RootSBin:  true,
	RootSrv:   true,
	RootSys:   true,
	RootTmp:   true,
	RootUsr:   true,
	RootVar:   true,
}

type LinkInfo struct {
	SourceFile   string `json:"source_file"`
	SoftLinkFile string `json:"soft_link_file"`
}

type OperateUnit struct {
	Type       FileType  `json:"type"`        // 文件类型
	Src        string    `json:"src"`         // 文件原始路径
	Dst        string    `json:"dst"`         // 文件目的路径
	Authority  string    `json:"authority"`   // 文件权限
	ForceCover bool      `json:"force_cover"` // 是否强制覆盖
	LinkInfo   *LinkInfo `json:"link_info"`   // 设置软连接
}

type OperateGroup struct {
	RootName string        `json:"root"`
	List     []OperateUnit `json:"list"`
}

// 支持的文件目录
type Support struct {
	SrcRoot      string         `json:"src_root"`
	DstRoot      string         `json:"dst_root"`
	RootDirList  []string       `json:"root_dir_list"`
	FileTypeList []string       `json:"file_type_list"`
	Group        []OperateGroup `json:"group"`
}

var (
	SrcRoot = "./"
	DstRoot = "./"
)