package operation

import (
	"encoding/json"
	"errors"
	"fmt"
	"os"
	"os/exec"
	"path/filepath"
)

func init() {
	var err error
	SrcRoot,err = filepath.Abs(SrcRoot)
	if err != nil || SrcRoot == "/" {
		fmt.Println("[init]Get Src Root Abs path failed,",err)
		os.Exit(1)
	}
	DstRoot,err = filepath.Abs(SrcRoot)
	if err != nil || DstRoot == "/" {
		fmt.Println("[init]Get Dst Root Abs path failed,",err)
		os.Exit(1)
	}
	fmt.Println("[init] Current SrcRoot[",SrcRoot,"] DstRoot[",DstRoot,"]")
}

// 定义对文件类型的支持
func IsFileSupport(fileType FileType) bool {
	support, ok := fileSupport[fileType]
	if !support || !ok {
		return false
	}
	return true
}

// 定义对Root目录类型的支持
func IsRootSupport(rootName RootName) bool {
	support, ok := rootSupport[rootName]
	if !support || !ok {
		return false
	}
	return true
}

func (u OperateUnit)ExecCommand(command string) error {
	if len(command) <= 0 {
		return errors.New("command is nil")
	}

	cmd := exec.Command("/bin/bash", "-c", command)
	if cmd == nil {
		return errors.New("generate cmd failed")
	}
	output, err := cmd.Output()
	if err != nil {
		fmt.Printf("Execute Shell:%s failed with error:%s", command, err.Error())
		return err
	}
	fmt.Printf("Execute Shell:%s finished with output:\n%s", command, string(output))
	return nil
}
func (u OperateUnit)Cook() error {
	fmt.Printf("[OperateUnit][Cook] %v\n",u)
	command := "cp -f "+SrcRoot+"/"+u.Src+" "+DstRoot+"/"+u.Dst+" && chmod -R "+u.Authority+" "+DstRoot+"/"+u.Dst
	return u.ExecCommand(command)
}

func (g OperateGroup)checkDataValid() bool {
	if g.List == nil || len(g.List) <= 0 {
		return false
	}
	for i,v := range g.List {
		// 检查源路径
		srcLen := len(v.Src)
		if srcLen <= 0 || srcLen >SrcPathMaxSize {
			fmt.Println("[checkDataValid] Error: Src Path failed, Name[",g.RootName,"] Index[",i,"]")
			return false
		}

		// 检查目的路径
		dstLen := len(v.Dst)
		if dstLen <= 0 || dstLen >SrcPathMaxSize {
			fmt.Println("[checkDataValid] Error: Dst Path failed, Name[",g.RootName,"] Index[",i,"]")
			return false
		}
		// 检查文件类型
		if !IsFileSupport(v.Type) {
			return false
		}
	}
	return true
}
func (g OperateGroup)Cook() error {
	if IsRootSupport(RootName(g.RootName)) {
		return errors.New("file name not support")
	}
	if !g.checkDataValid() {
		return errors.New("file check Invalid")
	}
	for i, v := range g.List {
		if err := v.Cook(); err != nil {
			fmt.Println("[OperateGroup][Cook]Index[",i,"] failed[",err,"]")
			return err
		}
	}
	return nil
}

func (s *Support)SetRootPath()  error {
	if s == nil {
		return errors.New("support is nil")
	}
	if s.SrcRoot != "" {
		SrcRoot = s.SrcRoot
	}
	if s.DstRoot != "" {
		DstRoot = s.DstRoot
	}
	var err error
	SrcRoot,err = filepath.Abs(SrcRoot)
	if err != nil || SrcRoot == "/" {
		fmt.Println("[Support][SetRootPath] Get Src Root Abs path failed,",err)
		return err
	}
	stat, errStat := os.Stat(SrcRoot)
	if errStat != nil {
		fmt.Println("[Support][SetRootPath] Error:[",errStat,"] IsExist[",os.IsNotExist(errStat),"]")
		return errStat
	}
	if !stat.IsDir() {
		fmt.Println("[Support][SetRootPath] Error: Path not DIR")
		return errors.New("not dir")
	}

	DstRoot,err = filepath.Abs(DstRoot)
	if err != nil || DstRoot == "/" {
		fmt.Println("[Support][SetRootPath] Get Dst Root Abs path failed,",err)
		return err
	}
	stat, errStat = os.Stat(DstRoot)
	if errStat != nil {
		fmt.Println("[Support][SetRootPath] Error:[",errStat,"] IsExist[",os.IsNotExist(errStat),"]")
		return errStat
	}
	if !stat.IsDir() {
		fmt.Println("[Support][SetRootPath] Error: Path not DIR")
		return errors.New("not dir")
	}

	fmt.Println("[Support][SetRootPath] Current SrcRoot[",SrcRoot,"] DstRoot[",DstRoot,"]")
	return nil
}
// Unmarshal
func (s *Support)Unmarshal(data []byte) error {
	if s == nil || data == nil {
		return errors.New("support is nil")
	}
	if err := json.Unmarshal(data, s); err != nil {
		fmt.Println("[Support][Unmarshal] Error:",err)
		return err
	}
	fmt.Println("[Support][Unmarshal] Root Path[",s.SrcRoot,"][",s.DstRoot,"]")
	if err := s.SetRootPath(); err != nil {
		fmt.Println("[Support][Unmarshal] Error:",err)
		return err
	}
	return  nil
}
// Operate 操作
func (s *Support)Cook() error {
	if s == nil {
		return errors.New("support is nil")
	}
	// 遍历处理请求, 有失败则退出
	for i,v := range s.Group {
		if err := v.Cook(); err != nil {
			fmt.Println("[Support][Cook] Index[",i,"] Error: call v.Cook failed[",err,"]")
			return err
		}

	}
	return nil
}