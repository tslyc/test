package operation

import (
	"errors"
	"fmt"
	"io/ioutil"
	"os"
	"path/filepath"
)

func GetAbsFilePath(filePath string) (string, error) {
	return filepath.Abs(filePath)
}

func IsValidFile(filePath string) bool {
	if len(filePath) > DefaultMaxFilePath {
		fmt.Println("[IsValidFile] Error: File Path too lang, MaxSize[",DefaultFileMaxSize,"]")
		return false
	}
	absPath, err := GetAbsFilePath(filePath)
	if err != nil {
		return false
	}
	s, err := os.Stat(absPath)
	if err != nil {
		fmt.Println("[IsValidFile] Error:[",err,"] IsExist[",os.IsNotExist(err),"]")
		return false
	}
	if s.IsDir() {
		fmt.Println("[IsValidFile] Error: Path not File")
		return false
	}
	if s.Size() > DefaultFileMaxSize {
		fmt.Println("[IsValidFile] Error: File Size Too Large[",s.Size(),"]")
		return false
	}
	return true
}

// 读取全部文件内容
func ReadAll(filePath string) ([]byte, error) {
	if !IsValidFile(filePath) {
		return nil, errors.New("file path is invalid")
	}
	absPath, err := GetAbsFilePath(filePath)
	if err != nil {
		return nil, err
	}
	f, err := os.Open(absPath)
	if err != nil {
		return nil, err
	}
	return ioutil.ReadAll(f)
}

func GetConfigFromPath(path string) (string, error) {
	data, err := ReadAll(path)
	if err != nil {
		return "", err
	}
	return string(data), nil
}