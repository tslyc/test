package statistics

// 基本项定义
const (
	MaxUint32           = 1<<32 - 1   /* 统计项最大值 */
	DefaultModelLen     = 100
	DefaultStatListLen  = 1000
	DefaultSingleMapCap = 1000
)

// Item 统计项
type Item struct {
	name     string
	count    uint32
	startAt  int64
	lastTime int64
}

// OptionName 注册项名称，使用整数枚举
type OptionName uint32
// ModelName 注册的模块名
type ModelName  uint32

// Option 注册项
type Option struct {
	Name OptionName
	Describe string
}

// BasicRegInfo 基本初始化项
type BasicRegInfo struct {
	Name ModelName  /* 注册项名 */
	Cap  uint32     /* 容量大小 */
}

// StatInfo 单项统计管理
type StatInfo struct {
	cap  uint32       /* 最大容量 */
	used uint32       /* 已经使用的 */
	stat map[OptionName]*Item  /* 下标索引 */
}

// StatManage 统计管理
type StatManage struct {
	used  uint32
	info  map[ModelName]*StatInfo
}

// 统计管理
var manage *StatManage

