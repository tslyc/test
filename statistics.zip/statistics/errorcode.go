package statistics

import "errors"

var (
	ErrManageIsNil = errors.New("manage is nil")
	ErrRegNameExist= errors.New("reg name exist")
	ErrRegNameNotExist= errors.New("reg name not exist")
)
