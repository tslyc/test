package statistics

import "sync/atomic"

// SetName 设置统计项名称
func (item *Item)SetName(name string) {
	if nil == item {
		return
	}

	item.name = name
}

// GetName 获取统计项名称
func (item *Item)GetName() string {
	if nil == item {
		return ""
	}
	return item.name
}

// IncrCount 统计项递增
func (item *Item)IncrCount() {
	if nil == item {
		return
	}
	if  atomic.LoadUint32(&item.count) == MaxUint32 {
		return
	}
	atomic.AddUint32(&item.count, 1)
}

// DescCount 统计项递减
func (item *Item)DescCount() {
	if nil == item {
		return
	}
	if atomic.LoadUint32(&item.count) == 0 {
		return
	}
	atomic.AddUint32(&item.count,^uint32(1-1))
}

// AddCountN 统计项递增N
func (item *Item)AddCountN(tick uint32) {
	if nil == item {
		return
	}
	atomic.AddUint32(&item.count, tick)
}

// SubCountN 统计项递减N
func (item *Item)SubCountN(tick uint32) {
	if nil == item {
		return
	}
	atomic.AddUint32(&item.count,^uint32(tick-1))
}

//GetCount 获取统计项个数
func (item *Item)GetCount() uint32 {
	if nil == item {
		return 0
	}
	return atomic.LoadUint32(&item.count)
}

// CleanCount 清理统计项
func (item *Item)CleanCount() {
	if nil == item {
		return
	}
	atomic.StoreUint32(&item.count,0)
}

// Clean 清除统计项
func (item *Item)Clean() {
	if nil == item {
		return
	}
	item.name = ""
	atomic.StoreUint32(&item.count,0)
}

