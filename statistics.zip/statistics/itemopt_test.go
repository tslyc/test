package statistics

import (
	"testing"
	"time"
)

// TestManage Item测试
func TestItem(t *testing.T) {
	item := Item{}
	if item.GetName() != "" {
		t.Error("item name should empty")
	}

	item.SetName("ItemA")
	if item.GetName() != "ItemA" {
		t.Error("item should be ItemA")
	}

	for i := 0; i <100; i++ {
		go item.IncrCount()
	}
	time.Sleep(1*time.Second)
	if item.GetCount() != 100 {
		t.Error("item should be 100, real is:", item.GetCount())
	}

	for i := 0; i <100; i++ {
		go item.DescCount()
	}
	time.Sleep(1*time.Second)
	if item.GetCount() != 0 {
		t.Error("item should be 0, real is:",item.GetCount())
	}

	item.DescCount()
	if item.GetCount() != 0 {
		t.Error("item should be 0, real is:",item.GetCount())
	}
}
