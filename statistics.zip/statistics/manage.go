package statistics


// 初始化管理控制块
func init() {
	// manage Info初始化
	manage = &StatManage{
		used:0,
		// 初始化默认容量100，对于一个进程基本够用，减少内存重分配次数，不够会自动扩容
		info:  make(map[ModelName]*StatInfo, DefaultModelLen),
	}
}

func Init() {

}

// Register 初始化注册
func Register(reg BasicRegInfo ,opts []Option) error {
	if nil == manage {
		return ErrManageIsNil
	}
	if _,ok := manage.info[reg.Name]; ok {
		return ErrRegNameExist
	}
	length := uint32(len(opts))
	if length < reg.Cap {
		length = reg.Cap
	}
	manage.info[reg.Name] = &StatInfo{
		cap: length,
		used:0,
		stat: make(map[OptionName]*Item, length),
	}
	info := manage.info[reg.Name]
	for _,opt := range opts {
		info.stat[opt.Name] = &Item{
			name: opt.Describe,
			count:0,
		}
	}
	return nil
}

// AddOption 添加统计项
func AddOption(name ModelName, opts []Option) error {
	if nil == manage {
		return ErrManageIsNil
	}
	info,ok := manage.info[name]
	if !ok || nil == info {
		return ErrRegNameNotExist
	}
	for _,opt := range opts {
		info.stat[opt.Name] = &Item{
			name: opt.Describe,
			count:0,
		}
	}
	return nil
}

// OptionIncr 统计值递增
func OptionIncr(name ModelName, opt OptionName) {
	if nil == manage {
		return
	}
	info,ok := manage.info[name]
	if !ok || nil == info {
		return
	}
	info.stat[opt].IncrCount()
	return
}

// OptionDesc 统计值减
func OptionDesc(name ModelName, opt OptionName) {
	if nil == manage {
		return
	}
	info,ok := manage.info[name]
	if !ok || nil == info {
		return
	}
	info.stat[opt].DescCount()
	return
}

// OptionCleanCount 清除统计值
func OptionCleanCount(name ModelName, opt OptionName) {
	if nil == manage {
		return
	}
	info,ok := manage.info[name]
	if !ok || nil == info {
		return
	}
	info.stat[opt].CleanCount()
	return
}

// OptionClean 清除统计项
func OptionClean(name ModelName, opt OptionName) {
	if nil == manage {
		return
	}
	info,ok := manage.info[name]
	if !ok || nil == info {
		return
	}
	info.stat[opt].Clean()
	return
}

// GetOtionCount 获取统计值
func GetOtionCount(name ModelName, opt OptionName) (uint32, error) {
	if nil == manage {
		return 0, ErrManageIsNil
	}
	info,ok := manage.info[name]
	if !ok || nil == info {
		return 0, ErrRegNameNotExist
	}
	return info.stat[opt].GetCount(),nil
}

// GetOptionItem 获取统计项
func GetOptionItem(name ModelName, opt OptionName) *Item {
	if nil == manage {
		return nil
	}
	info,ok := manage.info[name]
	if !ok || nil == info {
		return nil
	}
	return info.stat[opt]
}

