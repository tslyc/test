package statistics

import "testing"

// TestManage 管理测试
func TestManage(t *testing.T) {

}
